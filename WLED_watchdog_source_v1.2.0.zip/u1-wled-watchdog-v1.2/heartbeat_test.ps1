$WledIp = "192.168.1.63"
$Port = 21324
$IntervalSeconds = 3

$udp = New-Object System.Net.Sockets.UdpClient
$endpoint = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Parse($WledIp)), $Port
[byte[]]$packet = 85,49,87,76,69,68,72,66,1

Write-Host "Sending U1 heartbeat every $IntervalSeconds seconds to $WledIp`:$Port"
Write-Host "Press Ctrl+C to stop. The watchdog should turn LEDs off about 10 seconds later."

try {
    while ($true) {
        [void]$udp.Send($packet, $packet.Length, $endpoint)
        Start-Sleep -Seconds $IntervalSeconds
    }
}
finally {
    $udp.Close()
}
