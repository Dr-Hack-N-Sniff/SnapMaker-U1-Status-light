#include <cassert>
#include <cstdint>
#include "../usermod/watchdog_core.h"

int main() {
    WatchdogCore wd(10000);

    // Not armed until a valid heartbeat arrives.
    assert(!wd.isArmed());
    assert(!wd.shouldForceOff(20000));

    wd.heartbeat(1000);
    assert(wd.isArmed());
    assert(!wd.shouldForceOff(10999));
    assert(wd.shouldForceOff(11000));

    wd.heartbeat(12000);
    assert(!wd.shouldForceOff(21999));
    assert(wd.shouldForceOff(22000));

    return 0;
}
