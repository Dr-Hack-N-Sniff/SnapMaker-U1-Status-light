#pragma once
#include <cstddef>
#include <cstdint>
using byte = uint8_t;
struct JsonObject {};
class Usermod {
public:
    virtual ~Usermod() = default;
    virtual void loop() {}
    virtual void onUdpPacket(uint8_t*, size_t) {}
};
extern uint8_t bri;
extern uint8_t briLast;
extern uint32_t fakeMillis;
inline uint32_t millis() { return fakeMillis; }
static constexpr byte CALL_MODE_NO_NOTIFY = 5;
extern int stateUpdatedCalls;
inline void stateUpdated(byte) { ++stateUpdatedCalls; if (bri > 0) briLast = bri; }
#define REGISTER_USERMOD(instance)
