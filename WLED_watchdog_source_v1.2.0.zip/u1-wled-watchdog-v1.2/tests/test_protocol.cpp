#include <cassert>
#include <cstdint>
#include <cstring>
#include "../usermod/heartbeat_protocol.h"

int main() {
    const uint8_t good[] = {'U','1','W','L','E','D','H','B',1};
    const uint8_t badMagic[] = {'U','1','W','L','E','D','X','X',1};
    const uint8_t badVersion[] = {'U','1','W','L','E','D','H','B',2};
    const uint8_t shortPkt[] = {'U','1','W'};

    assert(isValidHeartbeat(good, sizeof(good)));
    assert(!isValidHeartbeat(badMagic, sizeof(badMagic)));
    assert(!isValidHeartbeat(badVersion, sizeof(badVersion)));
    assert(!isValidHeartbeat(shortPkt, sizeof(shortPkt)));
    return 0;
}
