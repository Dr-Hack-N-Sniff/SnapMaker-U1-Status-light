#include <cassert>
#include <cstdint>
uint8_t bri = 45;
uint8_t briLast = 45;
uint32_t fakeMillis = 0;
int stateUpdatedCalls = 0;

#include "../usermod/u1_heartbeat_watchdog.cpp"

int main() {
    U1HeartbeatWatchdog wd;
    const uint8_t heartbeat[] = {'U','1','W','L','E','D','H','B',1};

    // No heartbeat yet: watchdog must not arm or shut normal WLED down.
    fakeMillis = 20000;
    wd.loop();
    assert(bri == 45);

    // First heartbeat arms watchdog without changing visible state.
    fakeMillis = 21000;
    wd.onUdpPacket(const_cast<uint8_t*>(heartbeat), sizeof(heartbeat));
    assert(bri == 45);

    // Before timeout, effect/brightness remains untouched.
    fakeMillis = 30999;
    wd.loop();
    assert(bri == 45);

    // At 10 seconds without heartbeat, LEDs turn off.
    fakeMillis = 31000;
    wd.loop();
    assert(bri == 0);

    // A valid heartbeat restores the prior brightness/effect state.
    fakeMillis = 33000;
    wd.onUdpPacket(const_cast<uint8_t*>(heartbeat), sizeof(heartbeat));
    assert(bri == 45);

    return 0;
}
