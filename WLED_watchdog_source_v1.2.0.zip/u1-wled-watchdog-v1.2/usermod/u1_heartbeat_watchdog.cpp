#include "wled.h"
#include "watchdog_core.h"
#include "heartbeat_protocol.h"

class U1HeartbeatWatchdog : public Usermod {
private:
    static constexpr uint32_t TIMEOUT_MS = 10000;
    WatchdogCore watchdog{TIMEOUT_MS};
    bool forcedOff = false;
    uint8_t restoreBrightness = 128;

    void forceOff() {
        if (!forcedOff) {
            if (bri > 0) restoreBrightness = bri;
            forcedOff = true;
        }

        if (bri != 0) {
            bri = 0;
            stateUpdated(CALL_MODE_NO_NOTIFY);
        }
    }

    void restoreIfNeeded() {
        if (!forcedOff) return;
        forcedOff = false;

        if (bri == 0 && restoreBrightness > 0) {
            bri = restoreBrightness;
            stateUpdated(CALL_MODE_NO_NOTIFY);
        }
    }

public:
    void loop() override {
        if (watchdog.shouldForceOff(millis())) {
            forceOff();
        }
    }

    void onUdpPacket(uint8_t* payload, size_t len) override {
        if (!isValidHeartbeat(payload, len)) return;

        watchdog.heartbeat(millis());
        restoreIfNeeded();
    }
};

static U1HeartbeatWatchdog u1HeartbeatWatchdog;
REGISTER_USERMOD(u1HeartbeatWatchdog);
