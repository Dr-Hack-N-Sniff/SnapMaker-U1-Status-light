#pragma once
#include <cstddef>
#include <cstdint>

inline bool isValidHeartbeat(const uint8_t* payload, size_t len) {
    static constexpr uint8_t MAGIC[] = {'U','1','W','L','E','D','H','B'};
    static constexpr uint8_t VERSION = 1;
    if (!payload || len != sizeof(MAGIC) + 1) return false;
    for (size_t i = 0; i < sizeof(MAGIC); ++i) {
        if (payload[i] != MAGIC[i]) return false;
    }
    return payload[sizeof(MAGIC)] == VERSION;
}
