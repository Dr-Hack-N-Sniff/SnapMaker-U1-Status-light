#pragma once
#include <cstdint>

class WatchdogCore {
public:
    explicit WatchdogCore(uint32_t timeoutMs) : timeoutMs_(timeoutMs) {}

    void heartbeat(uint32_t nowMs) {
        lastHeartbeatMs_ = nowMs;
        armed_ = true;
    }

    bool isArmed() const { return armed_; }

    bool shouldForceOff(uint32_t nowMs) const {
        if (!armed_) return false;
        return static_cast<uint32_t>(nowMs - lastHeartbeatMs_) >= timeoutMs_;
    }

private:
    uint32_t timeoutMs_;
    uint32_t lastHeartbeatMs_ = 0;
    bool armed_ = false;
};
