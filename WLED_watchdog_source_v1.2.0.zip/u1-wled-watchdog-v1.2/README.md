# Snapmaker U1 WLED Heartbeat Watchdog - v1.2 Experimental

This is the WLED-side prototype for the optional Snapmaker U1 v1.2 heartbeat failsafe.

## Target behavior

- Normal WLED effects remain untouched while valid heartbeat packets arrive.
- Heartbeat interval: 3 seconds.
- No valid heartbeat for 10 seconds: WLED turns the LEDs off.
- When heartbeat returns, the usermod restores the brightness that was active before it forced the LEDs off. The normal U1 status bridge can then overwrite the state as needed.
- The watchdog does not arm until the first valid heartbeat arrives.

## Heartbeat packet

The usermod listens through WLED's normal UDP usermod hook. A valid packet is exactly 9 bytes:

`U1WLEDHB` followed by version byte `0x01`.

It does not use WLED realtime mode, so receiving a heartbeat should not blank or override the current effect.

## Files

- `usermod/u1_heartbeat_watchdog.cpp` - WLED usermod wrapper.
- `usermod/watchdog_core.h` - timeout logic.
- `usermod/heartbeat_protocol.h` - packet validation.
- `heartbeat_test.ps1` - Windows PowerShell heartbeat generator for bench testing.
- `tests/` - host-side tests for timeout, protocol, and visible-state behavior.

## Safety

This is experimental source code, not a firmware image. Do not flash anything from this folder directly.

The existing U1 v1.1.0 bridge does not need to be changed to run the PowerShell/WLED-side test once a custom WLED firmware containing this usermod has been built.
